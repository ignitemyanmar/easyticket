<?php
	Class Cinema extends Eloquent 
	{ 
		protected $table = 'tbl_cinema';
	}
?>
