<?php
	Class CronJob extends Eloquent 
	{ 
		protected $table = 'cron_job';
		public $timestamps = false;
	}
?>
