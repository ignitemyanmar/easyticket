<?php
	Class CronManager extends Eloquent 
	{ 
		protected $table = 'cron_manager';
		public $timestamps = false;
	}
?>
