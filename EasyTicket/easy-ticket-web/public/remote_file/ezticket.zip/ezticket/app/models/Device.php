<?php
	Class Device extends Eloquent 
	{ 
		protected $table = 'tbl_device';
	}
?>
