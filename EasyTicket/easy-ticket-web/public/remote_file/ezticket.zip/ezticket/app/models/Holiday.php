<?php
	Class Holiday extends Eloquent 
	{ 
		protected $table = 'tbl_holidays';
	}
?>
