<?php
	Class Movie extends Eloquent 
	{ 
		protected $table = 'tbl_movies';
	}
?>
