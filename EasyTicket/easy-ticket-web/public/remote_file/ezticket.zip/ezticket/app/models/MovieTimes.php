<?php
	Class MovieTimes extends Eloquent 
	{ 
		protected $table = 'tbl_movietimes';
		public $timestamps = false;
	}
?>
