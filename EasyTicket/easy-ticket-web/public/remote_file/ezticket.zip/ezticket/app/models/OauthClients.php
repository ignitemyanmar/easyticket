<?php
	Class OauthClients extends Eloquent 
	{ 
		protected $table = 'oauth_clients';
	}
?>
