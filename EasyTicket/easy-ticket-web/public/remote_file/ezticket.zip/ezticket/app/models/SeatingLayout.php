<?php
	Class SeatingLayout extends Eloquent 
	{ 
		protected $table = 'tbl_seatinglayout';
		public $timestamps = false;
	}
?>
