<?php
	Class ShowTime extends Eloquent 
	{ 
		protected $table = 'tbl_showtime';
		public $timestamps = false;
	}
?>
