<?php
	Class SubCinema extends Eloquent 
	{ 
		protected $table = 'tbl_subcinema';
		public $timestamps = false;
	}
?>
