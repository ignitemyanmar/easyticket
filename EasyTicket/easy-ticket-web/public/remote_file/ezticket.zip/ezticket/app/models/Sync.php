<?php
	Class Sync extends Eloquent 
	{ 
		protected $table = 'tbl_sync';
		public $timestamps = false;
	}
?>
