<?php
	Class TargetLabel extends Eloquent 
	{ 
		protected $table = 'tbl_target_label';
		public $timestamps = false;
	}
?>
