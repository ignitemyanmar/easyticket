<?php
	Class TicketClass extends Eloquent 
	{ 
		protected $table = 'tbl_ticketclass';
		public $timestamps = false;
	}
?>
