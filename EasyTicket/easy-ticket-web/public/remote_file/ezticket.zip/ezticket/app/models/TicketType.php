<?php
	Class TicketType extends Eloquent 
	{ 
		protected $table = 'tbl_tickettype';
		public $timestamps = false;
	}
?>
